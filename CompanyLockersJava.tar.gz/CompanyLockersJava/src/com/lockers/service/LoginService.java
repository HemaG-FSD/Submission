package com.lockers.service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.lockers.dto.User;

public class LoginService {
	
	
	public void registerUser(User u1){
		//Write User properties to Database file
		try {
		FileOutputStream fos = new FileOutputStream("Database.tmp",true);
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		
			oos.writeObject(u1);
			oos.close();
			fos.close();
		} catch (IOException e) {
			System.err.println("Error"+e.getMessage());
		}
		System.out.println("User Registered successfully");
		
	}
	
    public void login(User u1) {
    	try {
    	FileInputStream fis=new FileInputStream("Database.tmp");
    	ObjectInputStream ios=null;
    	
    	boolean cont=true;
    	boolean found=false;
    	
    	while(fis.available()>0 && cont) {
    		ios=new ObjectInputStream(fis);
    		Object temp=ios.readObject();
    		
    		if (temp!= null && (temp instanceof User)) {
		    		User user=(User)temp;
		    		System.out.println(user.toString());//Checking gthe objects that are read
		    		if(user.getUserName().equals(u1.getUserName()) &&
		    				user.getPassword().equals(u1.getPassword())) {
		    			found=true;
		    			System.out.println("Valid User...Logged in");
		    		}   
    		}
    		else {
  		      cont = false;
  		    }
    		}
    	 if(found==false){
    		 System.out.println("Invalid User...Please register to login");
    	 }
    	 fis.close();
    	 ios.close();
    		} catch (IOException e) {
    			System.err.println("Error"+e.getMessage());
    			e.printStackTrace();
    		} catch (ClassNotFoundException e) {
    			System.err.println("Error"+e.getMessage());
    			e.printStackTrace();
    		}
    		
		
    	
	}

}
