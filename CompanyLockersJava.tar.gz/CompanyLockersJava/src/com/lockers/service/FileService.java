package com.lockers.service;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

public class FileService {

	//Method to create a file in userFiles folder
	public void createFile(String fileName) {
		File file = new File(fileName); //initialize File object and passing path as argument  

		boolean result;  
		try   
		{  
		result = file.createNewFile();  //creates a new file  
		if(result)      // test if successfully created a new file  
		{  
		System.out.println("file created "+file.getCanonicalPath()); //returns the path string  
		}  
		else  
		{  
		System.out.println("File already exist at location: "+file.getCanonicalPath());  
		}  
		}   
		catch (IOException e)   
		{  
		System.out.println(e.getMessage());   //prints exception if any  
		}         // TODO Auto-generated method stub
		
	}

	public void deleteFile(String fileName) {
		
		try{
		File f= new File(fileName);           //file to be delete  
		
		
		if(f.delete())                      //returns Boolean value  
		{  
		System.out.println(f.getName() + " deleted");   //getting and printing the file name  
		}  
		else  
		{  
		System.out.println("failed");  
		}  
		}  
		catch(Exception e)  
		{  
			System.out.println(e.getMessage()); 
		}  
		
	}

	public void searchFile(String fileName) {
		
		File dir = new File(System.getProperty("user.dir"));
	      FilenameFilter filter = new FilenameFilter() {
	         public boolean accept (File dir, String name) { 
	            return name.equals(fileName);
	         } 
	      }; 
	      String[] children = dir.list(filter);
	      if (children == null) {
	         System.out.println("Either dir does not exist or is not a directory"); 
	      } else { 
	         for (int i = 0; i< children.length; i++) {
	            String filename = children[i];
	            System.out.println("File Found:"+filename);
	         } 
	      } 
		
	}

}
