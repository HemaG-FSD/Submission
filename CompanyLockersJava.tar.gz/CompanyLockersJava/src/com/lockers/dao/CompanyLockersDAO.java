package com.lockers.dao;

public class CompanyLockersDAO {

}
