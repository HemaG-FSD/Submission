package com.lockers.pl;

import java.util.Scanner;
/** Author: Hema G
 * Date: 09-May-2021
 */

import com.lockers.dto.User;
import com.lockers.service.FileService;
import com.lockers.service.LoginService;

public class CompanyLockers {
	
	public static void main(String args[]) {
		
		//Create object of LoginService
		LoginService ls= new LoginService();
		
		System.out.println("Welcome to Company Lockers");
		
		System.out.println("1-> Register\n2 -> Login");
		System.out.println("*************Enter your choice*****************");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		//New user Registration
		if(ch==1)
		{
			User u1=new User();
			String userName, password;
			System.out.println("Enter Your username");
			u1.setUserName(sc.next());
			System.out.println("Enter Your password");
			u1.setPassword(sc.next());
			ls.registerUser(u1);
			System.out.println("User Successfully Registered");
		}
		//Existing User Login
		else if(ch==2) {
			
			//Create objects of FileService
			FileService fileServ=new FileService();
			User u1=new User();
			String userName, password;
			System.out.println("Enter Your username");
			u1.setUserName(sc.next());
			System.out.println("Enter Your password");
			u1.setPassword(sc.next());
			ls.login(u1);
			//("Logged in");
			//Getting user preference
			System.out.println("*************Enter your choice*****************");
			System.out.println("1-> Add a File\n 2 -> Delete a file\n 3 -> Search a file:");
			int fileOps=sc.nextInt();
			//Create a new File
			if(fileOps==1) {
				String fileName;
				System.out.println("Enter the fileName");
				fileName=sc.next();
				fileServ.createFile(fileName);
			}
			
			if(fileOps==2) {
				String fileName;
				System.out.println("Enter the fileName");
				fileName=sc.next();
				fileServ.deleteFile(fileName);
			}
			
			if(fileOps==3) {
				String fileName;
				System.out.println("Enter the fileName");
				fileName=sc.next();
				fileServ.searchFile(fileName);
			}
		}
		else {
			System.out.println("Enter a valid choice");
		}
	}
}
